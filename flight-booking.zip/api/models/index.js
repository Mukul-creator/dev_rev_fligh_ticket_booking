module.exports = {
    user: require("./schema/user"),
    flight: require("./schema/flight"),
    booking: require('./schema/booking')
    
}